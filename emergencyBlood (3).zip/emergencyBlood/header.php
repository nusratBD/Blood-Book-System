<!DOCTYPE html>
<html>
<head>
	<title>bloodbook</title>
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
	
		
</head>
<body>
	<div class="bg-danger" style="height: 80px;">
		<div class="float: right float-md-left d-inline" style="height: 80px; width: 130px;"><img src="3.png"style="height: 70px; width: 120px; margin-left: 10px;">
		</div>
		<div class="float: right float-md-left d-inline" style="height: 80px; width: 700px; margin-left: 60px;">
			
			<div class="d-block" style="height: 20px; text-align: center;"><strong>No Worries for Emergency Blood</strong></div>

			<div class="d-block" style="height: 40px; margin-top: 28px; ">
				<a href="home.php" class="btn btn-light" style="margin-right: 35px; height: 30px;"><strong>Home</strong></a>
				<a href="donorRegistration.php" class="btn btn-light"style="margin-left: 25px; margin-right: 35px; height: 30px;"><strong>Donor Registration</strong></a>
				<a href="findBlood.php" class="btn btn-light"style="margin-left: 25px; margin-right: 35px; height: 30px"><strong>Find Blood</strong></a>
				<a href="donorVerification.php" class="btn btn-light" style="margin-left: 25px; height: 30px;"><strong>Donor Profile</strong></a>
			</div>
		</div>
		
		<div class="float: right bg-danger d-inline" style="height: 80px; width: 300px; margin-top: ; margin-right: 150px;"><table style="margin-left: ">
					<thead>
						<tr>
							<th><small>Phone Number</small></th>
							<th><small>Password</small></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<form>
							<td><input type="number" name="phone" style="margin-right: 10px; height: 22px;"></td>
							<td><input type="password" name="password" style="margin-right: 10px; height: 22px;"></td>
							<td><small style=""><a href="Profile.php"  class="btn-danger" style="padding: 2px; border-radius: 3px;">Sign Up</a></small></td>
							</form>
						</tr>
						<tr>
							<td></td>
							<td><small><a href="updatePass.php" style="color: yellow;">Reset Password</a></small></td>
							<td></td>
						</tr>
					</tbody>
				</table></div>
	</div>
	