<?php
	include 'header.php';
?>

<div class="container bg-danger" style="width: 500px; color: white; height: 40px; margin-top: 30px; border-radius: 10px; margin-bottom: 20px;" align="center">
	<h3>Payment Recite</h3>
</div>
<div class="container" style="width: 450px;">
<div class="flow: right d-inline-block bg-dark" style="color: white; width: 150px; height: 30px; border-radius: 5px;" align="center"><h5>Please Pay:</h5>
</div>

<div class="flow: left d-inline-block bg-dark" style="color: white; width: 230px; height: 30px; border-radius: 5px;" align="center"><h5><?php echo "1*900 = 900 TK";?></h5>
</div>
</div>

		<div class="container bg-danger" style="width: 200px; height: 30px; margin-top: 20px; border-radius: 10px; color: white;" align="center"><h5>Select Any One</h5></div>
<div class="container" style="width: 400px; margin-top: 20px; text-align: center;" >
	
	<div class="d-inline-block bg-dark" style="height: 30px; width: 80px; border-radius: 10px;"><a href="https://www.bkash.com/payment/" style="color: yellow;"><strong>bKash</strong></a></div>
	<div class="d-inline-block bg-dark" style="height: 30px; width: 80px; border-radius: 10px;"><a href="" style="color: yellow;"><strong>ROCKET</strong></a></div>
	<div class="d-inline-block bg-dark" style="height: 30px; width: 80px; border-radius: 10px;"><a href="" style="color: yellow;"><strong>NOGOD</strong></a></div>
	<div class="d-inline-block bg-dark" style="height: 30px; width: 100px; border-radius: 10px;"><a href="" style="color: yellow;"><strong>SURE CASH</strong></a></div>

	
</div>
<div class="container bg-primary" align="center" style="width: 700px; height: 40px; color: black; margin-top: 50px; border-radius: 10px;"><h4>You Must Pay Delivery Charge 120/= on hand</h4></div>

<?php 
		include 'footer.php';
	 ?>