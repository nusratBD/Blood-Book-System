<?php
	include 'header.php';
?>
<div class="container" style="margin-top: 20px; width: 500px;">

	<div align="center" class="bg-danger" style="height: 40px; color: White; margin-bottom: 10PX;"><h3>Blood Pre Order Form</h3>
	</div>



	<input type="text" name="" class="form-group form-control" placeholder="Enter your Name">
	<input type="text" name="" class="form-group form-control" placeholder="Enter your Phone Number">
	<div>
		<label><strong style="color: gray">Select Delivary Date:</strong></label><br>
				<div class="d-inline-block" style="width: 152px;" >
					
					<select class="form-control form-group">
						<option>Month</option>
						<option>Jan</option>
						<option>Feb</option>
						<option>Mar</option>
						<option>Apr</option>
						<option>May</option>
						<option>Jun</option>
						<option>Jul</option>
						<option>Aug</option>
						<option>Sep</option>
						<option>Oct</option>
						<option>Nov</option>
						<option>Dec</option>
						
					</select>
				</div>
				<div class="d-inline-block" style="width: 152px;">
					<select class="form-control form-group">
						
						<option>Date</option>
						<option>1</option>
						<option>3</option>
						<option>4</option>
						<option>5</option>
						<option>6</option>
						<option>7</option>
						<option>8</option>
						<option>9</option>
						<option>10</option>
						<option>11</option>
						<option>12</option>
						<option>13</option>
						<option>14</option>
						<option>15</option>
						<option>16</option>
						<option>17</option>
						<option>18</option>
						<option>19</option>
						<option>20</option>
						<option>21</option>
						<option>22</option>
						<option>23</option>
						<option>24</option>
						<option>25</option>
						<option>26</option>
						<option>27</option>
						<option>28</option>
						<option>29</option>
						<option>30</option>
						<option>31</option>
					</select>
			</div>
				<div class="d-inline-block" style="width: 152px;">
			<select class="form-control form-group">
						<option selected="">Time</option>
						
						<option>1 PM</option>
						<option>2 PM</option>
						<option>3 PM</option>
						<option>4 PM</option>
						<option>5 PM</option>
						<option>6 PM</option>
						<option>7 PM</option>
						<option>8 PM</option>
						<option>9 PM</option>
						<option>10 PM</option>
						<option>11 PM</option>
						<option>12 PM</option>
						<option>1 AM</option>
						<option>2 AM</option>
						<option>3 AM</option>
						<option>4 AM</option>
						<option>5 AM</option>
						<option>6 AM</option>
						<option>7 AM</option>
						<option>8 AM</option>
						<option>9 AM</option>
						<option>10 AM</option>
						<option>11 AM</option>
						<option>12 AM</option>
						
					</select>
					
				</div>
				<div>
					<select class="form-control form-group">
		<option selected="">Select Amount of <?php echo "A+ "; ?>Blood from here</option>
						<option>1 BAG</option>
						<option>2 BAGS</option>
						<option>3 BAGS</option>
						<option>4 BAGS</option>
						<option>5 BAGS</option>
						<option>6 BAGS</option>
						<option>7 BAGS</option>
						<option>8 BAGS</option>
						
				</select>
				</div>
				<input type="text" name="" class="form-group form-control" placeholder="Enter the Hospital Name">
</div>
<div class="container" style="width: 250px">
	<a href="pay.php" class="btn btn-primary" style="border-radius: 10px;"><strong>Click for Payment</strong></a>
</div>