<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodbook";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$id = $_POST['id'];
$phone = $_POST['phone'];

$sql = "UPDATE donorregistration SET phone = '$phone' WHERE id = $id";




if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}


header('Location:signUpSuccess.php');
