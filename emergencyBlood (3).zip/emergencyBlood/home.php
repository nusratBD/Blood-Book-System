<?php
	include 'header.php';
?>
	<div class="display-1 container">Welcome to 'Blood Book'</div>



<?php 
		include 'footer.php';
	 ?>