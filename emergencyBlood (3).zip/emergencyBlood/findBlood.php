<?php
	include 'header.php';
?>
<script type="text/javascript">
		
		alert("Are you finding Emergency Blood? If yes, please fill up the form given below:");

	</script>

	<div class="container bg-danger" style="margin-top: 20px; width: 400px; height: 30px; border-radius: 10px; text-align: center;">
		<h4 style="color: white;">
	Application for Emergency Blood
			</h4>
	</div>


	<div class="container" style="margin-top: 20px; width: 400px; color: gray;">
		<form action="blood.php" method="POST">
			<div>
			<div class="float: right d-inline-block" style="width: 380px;">
		<label for="demoName"><strong>Name:(Required)</strong></label>
		<input type="text" name="name" id="demoName" placeholder="Enter Your Full Name" class="form-control form-group" required="">
		<label for="demoPhone"><strong>Phone:(Required)</strong></label>
		<input type="text" name="name" id="demoPhone" placeholder="Enter Your Full Name" class="form-control form-group" required="">
		<label for="demoPhone"><strong>Email:(Required)</strong></label>
		<input type="email" name="name" id="demoPhone" placeholder="Enter Your Email" class="form-control form-group" required="">
		<label for="demoPhone"><strong>NID/Birth Certificate No:(Required)</strong></label>
		<input type="text" name="name" id="demoPhone" placeholder="Enter Your NID/BCN" class="form-control form-group" required="">
		</div>
			
		</div>

		<div>
			<label for="demoPName"><strong>Location:</strong></label><br>
			<div class="float: right d-inline-block" style="width: 182px;">
				<input type="text" name="name" id="demoPName" placeholder="District(Required)" class="form-control form-group">
				<input type="text" name="name" id="demoPName" placeholder="Word No(Optional)" class="form-control form-group">

			</div>
			<div class="float: left d-inline-block" style="width: 182px;">
				<input type="text" name="name" id="demoPName" placeholder="Hospital(Required)" class="form-control form-group">
				<input type="text" name="name" id="demoPName" placeholder="Bed No(Optional)" class="form-control form-group">
			</div>
		</div>
		<div>
				<div class="float: right d-inline-block" style="width: 182px;">
		<label for="demoPName"><strong>Desire Blood group</strong></label>
		<select class="form-control form-group">
						<option selected="">Select One</option>
						<option>A+</option>
						<option>B+</option>
						<option>O+</option>
						<option>AB+</option>
						<option>A-</option>
						<option>B-</option>
						<option>O-</option>
						<option>AB-</option>
						
						
					</select>
		</div>	
		<div class="float: left d-inline-block" style="width: 182px;">
		<label for="demoPName"><strong>Quantity</strong></label>
		<select class="form-control form-group">
						<option selected="">Select One</option>
						<option>1 BAG</option>
						<option>2 BAGS</option>
						<option>3 BAGS</option>
						<option>4 BAGS</option>
						<option>5 BAGS</option>
						<option>6 BAGS</option>
						<option>7 BAGS</option>
						<option>8 BAGS</option>
						<option>9 BAGS</option>
						<option>10 BAGS</option>
						<option>11 BAGS</option>
						<option>12 BAGS</option>
						<option>13 BAGS</option>
						<option>14 BAGS</option>
						
						
					</select>
		</div>
		</div>
		<div class="container" style="width: 200px;">
			<button class="btn-primary text-black" style="width: 200px;height: 40px; border-radius: 10px" type="submit"><strong>Sign Up</strong></button>

		</div>
		
		</form>
	</div>
	





<?php 
		include 'footer.php';
	 ?>