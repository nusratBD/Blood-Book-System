<?php
	include 'header.php';
	include 'connection.php';
?>
	
	<div class="container" style="width: 500px; margin-top: 40px;">

		<div class="bg-danger" style="height: 40px; margin-bottom: 10px; border-radius: 10px; color: white;" align="center"><h2>Please Sign Up Your Account</h2>
		</div>
		<form action="signUpSuccess.php" method="POST">
			<input type="number" name="phone" placeholder="Enter Your Account  Phone Number" class="form-group form-control">
			<input type="password" name="password" placeholder="Enter account password here" class="form-group form-control">
			<div class="container" align="center" style="margin-top: 30px;">
				<button class="btn-primary" style="width: 200px; height: 40px; border-radius: 10px;">
					<a href="signUpSuccess.php" style="color: white;" name="signUp"><strong>Sign Up</strong></a>
				</button>
				
			</div>
		
			</div>
		</form>
			<div class="container" align="center">
				<button class="btn-danger" style="width: 200px; margin-top: 10px;height: 25px; border-radius: 5px;">
					<a href="updatePass.php" style="color: yellow;" name="signUp"><strong><small>Reset Your Current Password</small></strong></a>
				</button>
	</div>


<?php 
		include 'footer.php';

	 ?>
