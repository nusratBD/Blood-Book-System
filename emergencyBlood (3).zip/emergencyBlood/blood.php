<?php
	include 'header.php';
?>
	<div class="container bg-danger" style="width: 600px; height: 40px; margin-top: 20px; border-radius: 10px; color: white;" align="center"><h3><strong>Welcome to <?php echo " 'Dhaka' "; ?> Blood Book: <?php echo "A+";?></strong></h3>
	</div>
	
	<div class="container" style="margin-top: 20px; width: 1000px;" align="center">

		<div class="float:right d-inline-block" style="width: 300px; height: 40px;">


			<div class="container bg-dark " style="color: white; width: 250px; border-radius: 10px;">
				<h3>Available Blood:</h3>
			</div>	
			

			<div class="container bg-dark " style="color: white; width: 250px; border-radius: 10px;">
				<h3>Available Donor:</h3>
				
			</div>
			
		</div>	
		
		<div class="float:right d-inline-block" style="width: 300px; height: 40px;">

			<div class="container bg-dark " style="color: white; width: 250px; border-radius: 10px;">
				<h3><?php echo "100 ";?>BAGS</h3>
			</div>	
			

			<div class="container bg-dark " style="color: white; width: 250px; border-radius: 10px;">
				<h3><?php echo "100";?></h3>
			</div>	
			
		</div>

		<div class="float:left d-inline-block" style="width: 300px; height: 40px;">
			
			<div class="container bg-dark " style="width: 300px; border-radius: 10px;">
				<h3><a href="order.php" style="color: yellow;">Click to Order Now</a></h3>
			</div>	
			

			<div class="container bg-dark " style="width: 300px; border-radius: 10px;">
				<h3><a href="preOrder.php" style="color: yellow">Click for Pre Order</a></h3>
			</div>	
			
		</div>
	</div>




<?php 
		include 'footer.php';
	 ?>