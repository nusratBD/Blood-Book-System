<?php
include 'connection.php';
date_default_timezone_set("Asia/Dhaka");
$i = date('d_m_y_h_i_sa');


$fileName ="profilePic/". $i.($_FILES['profilePic']['name']);



move_uploaded_file($_FILES['profilePic'] ['tmp_name'],$fileName);
if (isset($_POST['sub'])) {


	

$name = $_POST['name'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$district = $_POST['district'];
$thana = $_POST['thana'];
$birthDay = $_POST['birthDate'];
$birthMonth = $_POST['birthMonth'];
$birthYear = $_POST['birthYear'];
$bloodGroup = $_POST['bloodGroup'];
$lastDonation = $_POST['lastDonation'];
$lastDMonth = $_POST['lastDMonth'];
$lastDDate = $_POST['lastDDate'];
$gender = $_POST['gender'];
$wish = $_POST['wish'];

	


$profilePic = $fileName;





$sql = "INSERT INTO donorregistration (name, phone, password, district, thana, birthDay, birthMonth, birthYear, bloodGroup,	lastDonation, lastDMonth, lastDDate, gender, wish,profilePic)
VALUES ('$name', '$phone', '$password', '$district', '$thana', '$birthDay', '$birthMonth', '$birthYear','$bloodGroup', '$lastDonation', '$lastDMonth', '$lastDDate', '$gender', '$wish', '$profilePic')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
header('Location: profile.php');
?>
