<?php
	include 'header.php';
	include 'update_middle_link.php';
?>
<div style="margin-top: 50px;">
	<center>
		
		<form action="updatePPfinal.php" method="POST" enctype="multipart/form-data">
			<input type="hidden" name="id" value="<?php echo $id;?>">
<div class="form-group form-design">
					
				<label style="color: gray;"><strong>Upload Your New Profile Pic</strong></label><br>
				
				<input type="file" name="profilePic" style="margin-left: 95px;">
				
</div>
<div class="d-inline-block">
					<button class="btn-primary text-black" style="width: 75px;height: 35px; border-radius: 10px; margin-left:;" name="sub" type="submit"><strong>Submit</strong></button>
</div>
		</form>
	</center>
</div>