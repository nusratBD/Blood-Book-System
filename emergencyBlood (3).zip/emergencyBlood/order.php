<?php
	include 'header.php';
?>

<div class="container" style="margin-top: 20px; width: 500px;">
	<div align="center" class="bg-danger" style="height: 40px; color: White"><h3>Blood Order Form</h3></div>
	<div class="container bg-dark" align="center" style="width: 200px; margin-top: 10px; margin-bottom: 10px; color: white"><h4><?php echo "10/02/2020";?></h4></div>
	<input type="text" name="" class="form-group form-control" placeholder="Enter your Name">
	<input type="text" name="" class="form-group form-control" placeholder="Enter your Phone Number">
<select class="form-control form-group">
		<option selected="">Select Amount of <?php echo "A+ "; ?>Blood from here</option>
						<option>1 BAG</option>
						<option>2 BAGS</option>
						<option>3 BAGS</option>
						<option>4 BAGS</option>
						<option>5 BAGS</option>
						<option>6 BAGS</option>
						<option>7 BAGS</option>
						<option>8 BAGS</option>
						
</select>
<select class="form-control form-group">
		<option selected="">Select a time for blood delivary</option>
						<option>12 AM</option>
						<option>1 AM</option>
						<option>2 AM</option>
						<option>3 AM</option>
						<option>4 AM</option>
						<option>5 AM</option>
						<option>6 AM</option>
						<option>7 AM</option>
						<option>8 AM</option>
						<option>9 AM</option>
						<option>10 AM</option>
						<option>11 AM</option>
						<option>12 PM</option>
						<option>1 PM</option>
						<option>2 PM</option>
						<option>3 PM</option>
						<option>4 PM</option>
						<option>5 PM</option>
						<option>6 PM</option>
						<option>7 PM</option>
						<option>8 PM</option>
						<option>9 PM</option>
						<option>10 PM</option>
						<option>11 PM</option>
					
						
						
</select>
<input type="text" name="" class="form-group form-control" placeholder="Enter the Hospital Name">
</div>
<div class="container" style="width: 250px">
	<a href="pay.php" class="btn btn-primary" style="border-radius: 10px;"><strong>Click for Payment</strong></a>
</div>