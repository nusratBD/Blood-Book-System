<?php
	include 'header.php';
	
	include 'update_middle_link.php';


?>
<div class="container" style="margin-top: 50px;">
	<center>
	<form action="updatePhonefinal.php" method="POST">
		<input type="hidden" name="id" value="<?php echo $id;?>">
<div>
					<label class="text-muted"><strong>Set Your Phone Number which is available Now:</strong></label>
					</div>
					<div class="d-inline-block">
						<input type="number" name="phone" class="form-group form-control" value="<?php echo $donor['phone']?>">

					</div>
					<div class="d-inline-block">
					<button class="btn-primary text-black" style="width: 75px;height: 35px; border-radius: 10px; margin-left:;" name="sub" type="submit"><strong>Submit</strong></button>
				</div>
					</form>
					</center>
					</div>