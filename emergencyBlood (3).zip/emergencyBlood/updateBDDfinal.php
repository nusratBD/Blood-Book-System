<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodbook";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$id = $_POST['id'];
$lastDonation = $_POST['lastDonation'];
$lastDMonth = $_POST['lastDMonth'];
$lastDDate = $_POST['lastDDate'];
$sql = "UPDATE donorregistration SET lastDonation = '$lastDonation', lastDMonth = '$lastDMonth', lastDDate = '$lastDDate' WHERE id = $id";




if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}


header('Location:signUpSuccess.php');