<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodbook";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$id = $_GET['id'];



$sql = "SELECT * FROM donorregistration WHERE id = $id";

$result = mysqli_query($conn, $sql);
  while($row = mysqli_fetch_assoc($result)) {
  			
  	$donor = $row;
  }

?>