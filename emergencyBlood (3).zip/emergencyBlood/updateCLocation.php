<?php
	include 'header.php';
	
	include 'update_middle_link.php';


?>
<div class="container" style="margin-top: 50px;">
	<center>
	<form action="updateCLfinal.php" method="POST">
		<input type="hidden" name="id" value="<?php echo $id;?>">
<div>
					<label class="text-muted"><strong>Set Current District You are Locationg:</strong></label>
					</div>
					<div class="d-inline-block">
						<input type="text" name="district" class="form-group form-control" value="<?php echo $donor['district']?>">

					</div>
					<div class="d-inline-block">
					<button class="btn-primary text-black" style="width: 75px;height: 35px; border-radius: 10px; margin-left:;" name="sub" type="submit"><strong>Submit</strong></button>
				</div>
					</form>
					</center>
					</div>