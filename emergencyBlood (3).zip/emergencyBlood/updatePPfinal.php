<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodbook";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

date_default_timezone_set("Asia/Dhaka");
$i = date('d_m_y_h_i_sa');


$fileName ="profilePic/". $i.($_FILES['profilePic']['name']);



move_uploaded_file($_FILES['profilePic'] ['tmp_name'],$fileName);
if (isset($_POST['sub'])) {
	
$id = $_POST['id'];
$profilePic = $fileName;

$sql = "UPDATE donorregistration SET profilePic = '$profilePic' WHERE id = $id";

}
echo $profilePic;

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}


header('Location:signUpSuccess.php');
