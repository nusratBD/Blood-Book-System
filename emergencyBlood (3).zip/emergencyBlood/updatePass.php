<?php
	include 'header.php';
	
	// include 'update_middle_link.php';


?>
<div class="container" style="margin-top: 50px; width: 300px;">
	<center>
	<form action="updatePassfinal.php" method="POST">
		
<div>
					<label class="text-muted"><strong>Give Your Phone Number:</strong></label>
					</div>
					<div class="">
						<input type="number" name="phone" class="form-group form-control" value="<?php echo $donor['district']?>">

					</div>
					<div>
					<label class="text-muted"><strong>Set Your Password For this Number:</strong></label>
					</div>
					<div class="">
						<input type="Password" name="phone" class="form-group form-control" value="<?php echo $donor['district']?>">

					</div>

					<div class="">
					<button class="btn-primary text-black" style="width: 75px;height: 35px; border-radius: 10px; margin-left:;" name="sub" type="submit"><strong>Submit</strong></button>
				</div>
					</form>
					</center>
					</div>