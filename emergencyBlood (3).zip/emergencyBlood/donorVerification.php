<?php
	include 'header.php';
?>
	
	<div class="container" style="width: 500px; margin-top: 20px;" align="center">
		<p class="lead" style="border-radius: 10px; border: 2px solid red;">Are you Our Donor?</p>
		<a href="signUp.php" class="btn btn-outline-success">Yes</a>
		<a href="donorRegistration.php" class="btn btn-outline-danger">No</a>
	</div>



<?php 
		include 'footer.php';
	 ?>