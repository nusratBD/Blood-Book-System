<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodbook";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$phone = $_POST['phone'];
$password = $_POST['password'];

$sql = "UPDATE donorregistration SET password = '$password' WHERE phone = $phone";




if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}


header('Location:signUpSuccess.php');