<?php
	include 'connection.php';
	include 'header.php';
	?>
	
		<div class="bg-danger container" align="center" style="height: 40px; margin-top: 20px; margin-bottom: 10px; color: white; border-radius: 10px; width: 450px;">
			<?php 
  		$sql = "SELECT * FROM donorregistration ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sql);
mysqli_close($conn);
	
  		while($row = mysqli_fetch_assoc($result)) {
  	 	?>
		<h2><?php echo $row["name"]; ?></h2>
		
 		
		<div class="bg-dark container" align="center" style="height: 40px; width: 100px; margin-bottom: 10px; color: white; border-radius: 10px;">
		<h2><?php echo $row["bloodGroup"];?></h2>
		</div>
		<div class="container" style="width: 300px;">
		<div class="card">
			<form>
				<div class="bg-primary" align="center" style="height: 30px; border: 2px solid yellow">
					<a href="updateProfilePic.php?id=<?php echo $row['id'];?>" style="color: white;">Click here to Update Profile Pic</a>
				</div>
				<div style="height: 300px;">
					<img style="height: 300px; width: 268px;" src="<?php echo $row["profilePic"]; ?>"> </div>
					
				
			<!-- 	<input type="file" name="" class="card-img-top" ; text-align: center; margin-left: 30px; margin-top: 20px;"type="file"> -->

				
			
			<div class="card-body" class="d-inline-block">
				<div>
				<label style="color: gray;">Last Date of Blood Donation:</label>
			
				</div>
				<div class="d-inline-block bg-dark" align="center" style="height: 30px; width: 150px; color: white; border-radius: 10px;"><?php echo $row["lastDMonth"]; ?><?php echo $row["lastDDate"]; ?>, <?php echo $row["lastDonation"]; ?>
					
				</div>
				
				<div class="d-inline-block bg-primary" align="center" style="height: 30px; width: 70px; border-radius: 10px; border: 2px solid yellow">
					<a href="updateBDDate.php?id=<?php echo $row['id'];?>" style="color: white;">Update</a>
				</div>
			</div>
			<div class="card-body" class="d-inline-block">
				<div>
				<label style="color: gray; margin-right: 80px;">Current Location:</label>
			
				</div>
				<div class="d-inline-block bg-dark" align="center" style="height: 30px; width: 150px; color: white; border-radius: 10px;"><?php echo $row["district"];?>
				</div>
				
				
				<div class="d-inline-block bg-primary" align="center" style="height: 30px; width: 70px; border-radius: 10px; border: 2px solid yellow">
					<a href="updateCLocation.php?id=<?php echo $row['id'];?>" style="color: white;">Update</a>
				</div>



			</div>

			<!---->
			<div class="card-body" class="d-inline-block">
				<div>
				<label style="color: gray; margin-right: 80px;">Phone Number:</label>
			
				</div>
				<div class="d-inline-block bg-dark" align="center" style="height: 30px; width: 150px; color: white; border-radius: 10px;"><?php echo $row["phone"];?>
				</div>
				
				
				<div class="d-inline-block bg-primary" align="center" style="height: 30px; width: 70px; border-radius: 10px; border: 2px solid yellow;">
					<a href="updatePhone.php?id=<?php echo $row['id'];?>" style="color: white;">Update</a>
				</div>
			
					<?php
	}
	?>
	
			</div>
			</form>
			</div>
			<div class="bg-danger" style="height: 30px; color: white;" align="center"><small>Please, Always Keep your Profile Update</small></div>
			<div class="container" align="center" style="margin-top: 30px;">
				<button class="btn-primary" style="width: 150px; height: 40px; border-radius: 10px;">
					<a href="signOut.php" style="color: white;"><strong>Sign Out</strong></a>
				</button>
				<br><br>
			</div>
		</div>
	</div>


<?php 
		include 'footer.php';
	 ?>